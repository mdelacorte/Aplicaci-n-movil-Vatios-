from kivy.app import App
from kivy.uix.widget import Widget
from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from datetime import datetime
from kivy.uix.button import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.properties import ListProperty, BooleanProperty
from kivy.properties import ObjectProperty
from kivy.core.window import Window
from functools import partial
from datetime import datetime
import requests
import json
import os
from scrollviewprecios import ScrollViewPrecios

#para el kv precios
class HomeScreen(Screen):
    pass

#para el kv precios
class SettingScreen(Screen):
    pass

#Imagenes que funcionan como botones
class ImageButton(ButtonBehavior, Image):
    pass
#Imagenes que funcionan como botones
class LabelImage(Label, Image):
    pass

Builder.load_file("main.kv") #pillar el diseño
class MainAppWidget(Widget):
    pass


class MainApp(App):
    #datos fecha actual
    fecha_ahora = datetime.now()

    #URL
    url_precio_ahora  = requests.get("https://api.preciodelaluz.org/v1/prices/now?zone=PCB").json()
    url_precio_medio  = requests.get("https://api.preciodelaluz.org/v1/prices/avg?zone=PCB").json()
    url_precio_maximo = requests.get("https://api.preciodelaluz.org/v1/prices/max?zone=PCB").json()
    url_precio_minimo = requests.get("https://api.preciodelaluz.org/v1/prices/min?zone=PCB").json()
    url_todos_precios = requests.get("https://api.preciodelaluz.org/v1/prices/all?zone=PCB").json()
    url_precio_economico = requests.get("https://api.preciodelaluz.org/v1/prices/cheapests?zone=PCB&n=2").json()
    
    
    def build(self):
        #Window.clearcolor= (1,1,1) #para que el fondo sea blanco
        return MainAppWidget()
        #return GUI
    def on_start(self):
        #obtener y rellenar datos de la fecha (viernes 16 septiembre etc)
        
        fecha = str(self.fecha_ahora.day)+ " de " + self.get_mes(self.fecha_ahora.month)+ ", "+ str(self.fecha_ahora.year)
        #obtenemos el id en el diseño
        fecha_label = self.root.ids['home_screen'].ids['fecha_label']
        #ponemos en el diseño la fecha actual
        fecha_label.text = fecha

        hora = str(self.url_precio_ahora['hour'])
        hora_label = self.root.ids['home_screen'].ids['hora_label']
        hora_label.text = hora + ' h'

        #obtener y rellenar datos de precio y hora
        self.insertar_datos()
        #color del precio actual
        self.cambio_color_precio(self.url_precio_ahora['price'],'precio_color_actual')
        
        #insertar precios del dia
        self.insertar_precios_dia()


    def on_refresh(self):
        pass

    def change_screen(self, screen_name):
        screen_manager = self.root.ids['screen_manager']
        screen_manager.current = screen_name

    #funcion adicional para obtener el mes dependiendo del numero que haya
    def get_mes(self,mes):
        fecha = ['Enero','Febrero','Marzo','Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiempre', 'Octubre', 'Noviembre']
        return (fecha[mes-1])

    def insertar_precios_dia(self):
        #rellenar los precios en el Scroll
        counter = -1
        horas = ['00-01','01-02','02-03','03-04','04-05','05-06','06-07','07-08','08-09',
            '09-10','10-11','11-12','12-13','13-14','14-15','15-16','16-17','17-18','18-19',
            '19-20','20-21','21-22','22-23','23-24']

        hora_ahora = self.url_precio_ahora['hour']
        indice_hora = horas.index(hora_ahora) +1

        #ahora recorremos todos las horas
        precios_del_dia = self.root.ids['home_screen'].ids['informacion_precio_hora']
        for dia in self.url_todos_precios:
            precios_dia = self.url_todos_precios[dia]['price']
            hora_dia = self.url_todos_precios[dia]['hour']
            counter += 1 #aumentamos el counter

            #solo vamos a añadir la informacion al banner si es mas tarde o la misma hora
            if (counter >= indice_hora):
                print(indice_hora)
                print(counter)
                #primero comprobamos que imagen vamos a tener que usar para 
                imagen = 'rec-2.png'
                if precios_dia <= self.url_precio_medio['price']:
                    imagen = 'rec-3.png'

                precios = ScrollViewPrecios(price=str(precios_dia), 
                hour=str(hora_dia), 
                imagen_precio= imagen)

                precios_del_dia.add_widget(precios)

    def cambio_color_precio(self,precio,id):
        barato = False
        if (precio <= self.url_precio_medio['price']):
            print("es barato")
            barato = True
        
        if barato == True:
            #si el precio es barato, cambiaremos la imagen por la precio_bueno
            precio_color_actual = self.root.ids['home_screen'].ids[id]
            precio_color_actual.source = "iconos/rec-3.png"

    def insertar_datos(self):
        #Precio ACTUAL
        precio_actual = str(self.url_precio_ahora['price'])
        precio_actual_label = self.root.ids['home_screen'].ids['precio_actual']
        precio_actual_label.text = precio_actual + ' €/Mwh'
        #si el precio "is-cheap": false, "is-under-avg": false, se pone rojo, si no verde 
        #Fecha ACTUAL
        #hora_actual = str(self.url_precio_ahora['hour'])
        #hora_actual_label = self.root.ids['home_screen'].ids['hora_actual']
        #hora_actual_label.text = hora_actual
        
        #Precio MINIMO
        precio_minimo = str(self.url_precio_minimo['price'])
        precio_minimo_label = self.root.ids['home_screen'].ids['precio_minimo']
        precio_minimo_label.text = precio_minimo + ' €/Mwh'
        #si el precio "is-cheap": false, "is-under-avg": false, se pone rojo, si no verde 
        #Fecha MINIMO
        hora_minimo = str(self.url_precio_minimo['hour'])
        hora_minimo_label = self.root.ids['home_screen'].ids['hora_minimo']
        hora_minimo_label.text = hora_minimo + ' h'
        
        #Precio MEDIO
        #precio_medio = str(self.url_precio_medio['price'])
        #precio_medio_label = self.root.ids['home_screen'].ids['precio_medio']
        #precio_medio_label.text = precio_medio + ' €/Mwh'
        #si el precio "is-cheap": false, "is-under-avg": false, se pone rojo, si no verde 

        #Precio MAXIMO
        precio_maximo = str(self.url_precio_maximo['price'])
        precio_maximo_label = self.root.ids['home_screen'].ids['precio_maximo']
        precio_maximo_label.text = precio_maximo + ' €/Mwh'
        #si el precio "is-cheap": false, "is-under-avg": false, se pone rojo, si no verde 
        
        #Fecha MAXIMO
        hora_maximo = str(self.url_precio_ahora['hour'])
        hora_maximo_label = self.root.ids['home_screen'].ids['hora_maximo']
        hora_maximo_label.text = hora_maximo 

if __name__ == '__main__':
    MainApp().run()





"""class MyGridLayout(Widget):
    name = ObjectProperty(None)
    pizza = ObjectProperty(None)
    color = ObjectProperty(None)
    def press(self):
        name = self.name.text
        pizza = self.pizza.text
        color = self.color.text
        print(f"Hello {name}, your fav pizza is {pizza} and fav color is {color}!")
        #self.add_widget(Label(text=f"Hello {name}, your fav pizza is {pizza} and fav color is {color}!"))
"""