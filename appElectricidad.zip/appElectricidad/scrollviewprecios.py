from kivy.uix.gridlayout import GridLayout 
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.graphics import Color, Rectangle
import kivy.utils

class ScrollViewPrecios(GridLayout):
    rows = 1
    def __init__(self, **kwargs):
        super().__init__()
        #Editar apariencia canvas
        self.padding = 5
        self.size_hint = (0.2, 0.15)
        with self.canvas.before:
            Color(rgb=(kivy.utils.get_color_from_hex('FFFFFF')))
            self.radius = [18]
            self.size_hint = (0.2, 0.15)
            self.rect = Rectangle(size=self.size, pos=self.pos, radius=[18])
        self.bind(pos=self.update_rect, size=self.update_rect)

        #se necesita left layout PRECIO
        izq = FloatLayout()
        label_izq = Label(text = str(kwargs['hour'])+ ' h',font_size=13, color=(181,178,178,0.75), size_hint=(1, .5),  pos_hint={'center_x': 0.3,'center_y': 0.5})
        #añadirlo al widget
        izq.add_widget(label_izq)

        #float layout en el medio HORA
        medio = FloatLayout()
        medio_label = Label(text = str(kwargs['price'])+ ' €/Mwh', font_size=14, bold=True, color=(0,0,0,1), size_hint=(1, .5), pos_hint={'center_x': 0.5,'center_y': 0.5})
        #añadirlo al widget
        medio.add_widget(medio_label)

        #float layout en la dcha IMAGEN
        dcha = FloatLayout()
        dcha_image = Image(source='iconos/' + kwargs['imagen_precio'], size_hint=(0.3, 0.3), pos_hint={'center_x': 0.75,'center_y': 0.5})
        #añadirlo al widget
        dcha.add_widget(dcha_image)
        
        self.add_widget(izq)
        self.add_widget(medio)
        self.add_widget(dcha)

    #se vaya cambiando el tamaño
    def update_rect(self,*args):
        self.rect.pos = self.pos
        self.rect.size = self.size